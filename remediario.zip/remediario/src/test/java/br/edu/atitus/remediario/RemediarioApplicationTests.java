package br.edu.atitus.remediario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RemediarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
