package br.edu.atitus.remediario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RemediarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(RemediarioApplication.class, args);
	}

}
