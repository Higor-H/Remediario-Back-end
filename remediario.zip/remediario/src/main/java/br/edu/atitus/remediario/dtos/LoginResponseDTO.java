package br.edu.atitus.remediario.dtos;

public record LoginResponseDTO(String token) {
}